#include "quickunion.h"

QuickUnion::QuickUnion(int N)
{
    id = new QList<int>();
    sz = new QList<int>();
    for (int i = 0; i < N; ++i) {
        id->append(i);
        sz->append(1);
    }
    count = N;
}

void QuickUnion::connect(int p, int q){ // add connection between p and q
    int i = find(p);
    int j = find(q);
    if(i == j) return;
    if(sz->at(i) < sz->at(j)){
        id[i].value(j);
        sz[j].value(sz->at(j) + sz->at(i));
    } else {
        id[j].value(i);
        sz[i].value(sz->at(j) + sz->at(i));
    }
    count--;
}

int QuickUnion::find(int i){ // ROOT component identifier for p (0 to N-1)
    while(i != id->at(i))
        i = id->at(i);
    return i;
}

bool QuickUnion::connected(int p, int q){ // return true if p and q in the same component
    return find(p) == find(q);
}
